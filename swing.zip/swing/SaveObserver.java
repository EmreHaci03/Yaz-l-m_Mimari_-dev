package swing;

public interface SaveObserver {
    void onSave();
}
